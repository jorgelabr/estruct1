#include <stdio.h>

#define MAX_ESTUDIANTES 3
#define MAX_LONGITUD_NOMBRE 50

struct Estudiante {
    int numero_registro;
    char nombre[MAX_LONGITUD_NOMBRE];
    char carrera[MAX_LONGITUD_NOMBRE];
    int edad;
};

int main() {
    struct Estudiante estudiantes[MAX_ESTUDIANTES];

 

    for (int i = 0; i < MAX_ESTUDIANTES; i++) {
        printf("Estudiante %d\n", i+1);
        printf("Número de registro: ");
        scanf("%d", &estudiantes[i].numero_registro);
        printf("Nombre (con espacios entre nombre y apellido):\n");
        scanf("%s", estudiantes[i].nombre);
        printf("Carrera:\n");
        scanf("%s", estudiantes[i].carrera);
        printf("Edad:");
        scanf("%d", &estudiantes[i].edad);
        printf("\n");
    }

    for (int i = 0; i < MAX_ESTUDIANTES; ++i) {
        printf("Estudiante %d\n", i+1);
        printf("Numero de registro: %d\n", estudiantes[i].numero_registro);
        printf("Nombre: %s\n", estudiantes[i].nombre);
        printf("Carrera: %s\n", estudiantes[i].carrera);
        printf("Edad: %d\n", estudiantes[i].edad);
        printf("\n");
    }

    return 0;
}

