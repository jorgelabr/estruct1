#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// funcion aleatoria con timer
void aleatoriosConTimer(int arreglo[], int tamano)
{
   

    srand(time(NULL));

    for (int i = 0; i < tamano; i++)
    {
        arreglo[i] = rand() % 100;
    }

    

    // Calcula tiempo 
    
}

// Funcion para imprimir 
void imprimirArreglo(int arreglo[], int tamano)
{
    for (int i = 0; i < tamano; i++)
    {
        printf("%d ", arreglo[i]);
    }
    printf("\n");
}

// Funcion para llenar el arreglo 
void llenarArreglo(int arreglo[], int tamano)
{
    printf("Ingrese los elementos del arreglo:\n");
    for (int i = 0; i < tamano; i++)
    {
        scanf("%d", &arreglo[i]);
    }
}

// funcion para ordenar 
void ordenarArreglo(int arreglo[], int tamano)
{
    for (int i = 0; i < tamano - 1; i++)
    {
        for (int j = 0; j < tamano - i - 1; j++)
        {
            if (arreglo[j] > arreglo[j + 1])
            {
                int temp = arreglo[j];
                arreglo[j] = arreglo[j + 1];
                arreglo[j + 1] = temp;
            }
        }
    }
}

int main()
{
    int tamano;
    
     clock_t start_time, end_time;

    start_time = clock();

    // preguntar tamaño
    printf("Ingrese el tamaño del arreglo: ");
    scanf("%d", &tamano);

    int arreglo[tamano];

    // llenar con randoms y calcular tiempo
    aleatoriosConTimer(arreglo, tamano);

    printf("Arreglo original: ");
    imprimirArreglo(arreglo, tamano);

    // ordenar 
    ordenarArreglo(arreglo, tamano);

    printf("Arreglo ordenado: ");
    imprimirArreglo(arreglo, tamano);

    // tiempo final
    end_time = clock();
    
    double time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    // imprime el tiempo
    printf("Tiempo para llenar con aleatorios: %.6f segundos\n", time_taken);
    
    return 0;
}
