#include <stdio.h>

// declarar estructura coshina
struct DispositivoRed {
    char tipo[20];
    int puertos;
    char direccionIP[15];
};

int main() {
    // arrregloooooooooo
    struct DispositivoRed arregloDispositivos[5];

    // puntero
    struct DispositivoRed *ptrDispositivos = arregloDispositivos;

    // inicializar toa la cosa
    for (int i = 0; i < 5; i++) {
        printf("Ingrese información para el Dispositivo %d:\n", i + 1);
        printf("Tipo: ");
        scanf("%19s", (ptrDispositivos + i)->tipo); // jose lo puso 
        printf("Puertos: ");
        scanf("%d", &(ptrDispositivos + i)->puertos);
        printf("Dirección IP: ");
        scanf("%14s", (ptrDispositivos + i)->direccionIP); // jose lo puso
    }

    // imprimir 
    //dios acaba mi sufrimiento
    printf("\nResultados:\n");
    for (int i = 0; i < 5; i++) {
        printf("Dispositivo %d:\n", i + 1);
        printf("Tipo: %s\n", (ptrDispositivos + i)->tipo);
        printf("Puertos: %d\n", (ptrDispositivos + i)->puertos);
        printf("Dirección IP: %s\n", (ptrDispositivos + i)->direccionIP);
        printf("\n");
    }

    return 0;
}
