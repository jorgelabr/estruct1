#include <stdio.h>

int main()
{

    int a = 10;
    int b = 10;
    
  
    int *punteroA = &a;
    int *punteroB = &b;
  
    printf("Variable a: %d\t A of a: %p\n", *punteroA, &a);
    printf("Variable b: %d\t A of b: %p\n", *punteroB, &b);
  
    printf("Hexa B: %p\n", &*punteroB);
    printf("Hexa A: %p\n", &*punteroA);
    
    return 0;
}
