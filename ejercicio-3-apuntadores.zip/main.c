#include <stdio.h>

int main()
{
    int a=10;
    int b=20;
    int resultado=0;
    
    int *puntero_a=&a;
    int *puntero_b=&b;
    
    resultado=*puntero_a+*puntero_b;
    printf("Resultado:%d\na:%d\nb:%d\n", resultado, *puntero_a,*puntero_b);
    
    *puntero_a=30;
    resultado=*puntero_a+*puntero_b;
    printf("Resultado:%d\na:%d\nb:%d\n", resultado, *puntero_a,*puntero_b);
    
    
    
    return 0;
}