#include <stdio.h>

int main()
{
    int numero=42;
    
    int *puntero = &numero;
    
    printf("%d\n", *puntero);
    
    *puntero=45;
    
    printf("%d", *puntero);
    
    
    
    
    return 0;
}