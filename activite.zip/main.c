#include <stdio.h>

typedef struct 
{
    char Nombre;
    int cantidad;
    float precio;
} Producto; 

int main()
{
    Producto producto1; 
    Producto *puntero; 

    producto1.Nombre = 'A';
    producto1.cantidad = 10;
    producto1.precio = 19.99;

    puntero = &producto1; 

    printf("Nombre: %c\nCantidad: %d\nPrecio: %f", puntero->Nombre, puntero->cantidad, puntero->precio);

    return 0;
}
