#include <stdio.h>

 

struct Motor {

    int numeroCilindros;

    float capacidadLitros;

};

 

struct Llanta {

    int diametroPulgadas;

    char tipo[20];

};

 

struct Puerta {

    char tipoApertura[20];

    int electrica;

};

 

struct Auto {

    char marca[20];

    char modelo[20];

    struct Motor motor;

    struct Llanta llantaDelantera;

    struct Llanta llantaTrasera;

    struct Puerta puertaIzquierda;

    struct Puerta puertaDerecha;

};

 

int main() {

struct Llanta llantafregada; 
int Cuatrollantas= sizeof(llantafregada)*4;
printf("Tamaño de 4 llantas en bytes: %d\nTamaño de  4 llantas en bits:%d\nTamaño de 4 llantas en nibbles: %d ", sizeof(llantafregada)*4, sizeof(llantafregada)*16,sizeof(llantafregada)*8);


return 0;
}